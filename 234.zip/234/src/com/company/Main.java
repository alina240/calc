package com.company;
import java.io.IOException;
import java.util.Scanner;

/**
 * класс Main для реализации калькулятора
 * @author Alina
 */
public class Main {
    public static void main(String[] args) throws IOException {
        String a, b, c;
        Scanner scanner = new Scanner(System.in);
        String string = getString(scanner);
        String[] data = getS(string);;
        if(!isResult(string)){
            System.out.println("Некорректный тип данных");

        } else{
            a = data[0];
            b = data[1];
            c = data[2];

            int q = getQ(a);
            int w = getQ(c);

            String operation= b;
            switch (operation) {

                case ("-")://выполнение операции вычитания
                    System.out.println(sub(q, w));
                    break;
                case ("+")://выполнение операции сложения
                    System.out.println(add(q, w));
                    break;
                case (":")://выполнение операции деления
                    System.out.println(div(q, w));
                    break;
                case ("%"):// операция по выявлению остатка
                    System.out.println(remains(q, w));
                    break;
                case ("*")://выполнение операции по умножению
                    System.out.println(multiply(q, w));
                    break;
                case ("^")://возведение в степень
                    System.out.println(degree(q, w));
                    break;
            }
        }

    }

    /**
     * метод для преобразования строки в число
     * @param a  строка которую преобразуем в число
     * @return возвращает проеобразованную строку к числовому типу
     */
    private static int getQ(String a) {
        return Integer.parseInt(a);
    }

    /**
     * метод делит строку по пробелам
     * @param string исходная строка,которую делит по пробелам
     * @return возвращает строковый массив
     */
    private static String[] getS(String string) {
        return string.split(" ");
    }

    /**
     * метод считывает введенную строку
     * @return возвращает введенную строку
     */
    private static String getString(Scanner scanner) {
        return scanner.nextLine();
    }

    /**
     * метод возвращает true, если введенная строка соответсвует регулярному выражению, иначе false
     * @param string введенная строка
     * @return возвращает true, если введено правильно, иначе false
     */
    private static boolean isResult(String string) {
        return string.matches("\\d+\\s[\\+\\-\\*\\/\\%\\^]\\s\\d+");
    }

    /**
     * метод осуществляет операцию по возведению в степень
     * @param q первый операнд
     * @param w второй операнд
     * @return возвращает результат
     */
    private static double degree(int q, int w) {
        return Math.pow(q, w);
    }

    /**
     * Метод для умножения
     * @param q первый операнд
     * @param w второй операнд
     * @return возвращает результат
     */
    static int multiply(int q, int w) {
        return q * w;
    }
    /**
     * Метод для выделения остатка
     * @param q первый операнд
     * @param w второй операнд
     * @return возвращает результат
     */
    static int remains(int q, int w) {
        return q % w;
    }
    /**
     * Метод осуществляет деление
     * @param q первый операнд
     * @param w второй операнд
     * @return возвращает результат
     */
    static int div(int q, int w) {
        return q / w;
    }
    /**
     * Метод осуществляет сложение
     * @param q первый операнд
     * @param w второй операнд
     * @return возвращает результат
     */
    static int add(int q, int w) {
        return q + w;
    }
    /**
     * Метод осуществляет вычитание
     * @param q первый операнд
     * @param w второй операнд
     * @return возвращает результат
     */
    static int sub(int q, int w) {
        return q - w;
    }
}